This is the source code of Bridge Builder Mini v0.1.
Open in Android Studio or VS Code.
Run: flutter pub get && flutter build apk